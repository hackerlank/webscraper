/// <reference path="./include.d.ts" />

var request = require('request');
var fs = require('fs');
var sTool = require('./toolkits/stringtool');
var async = require('async');


var tasks = JSON.parse(fs.readFileSync('./data.json'));

async.mapLimit(tasks, 1, function(entity, callback) {
        generate(entity, callback);
}, function(err) {
    if(err) console.log(err);
});




function generate(entity, callback) {
    var emailAddr = entity['Company E-Mail'];
    console.log(emailAddr);
    var address1 = entity['Address 1'];
    var city = entity['City'];
    var companyName = entity['Company Name'];
    var phone1 = entity['phone1'];
    var phone2 = entity['phone2'];
    var phone3 = entity['phone3'];
    var companyWebsite = entity['Company Website'];
    var businessType = entity['Type Of Business'];
    var sis = entity['SIS'];
    var zip = entity['Zip/Post Code'];


    var rstring = sTool.randomStr(8);
    // var emailAddr = rstring + '@js.com';
    var refNumber = '16' + sTool.randomNumber(8);
    // var refNumber = '1617709091';
    console.log(refNumber);

    var signUpHar = {
        "postData": {
            "params": [{
                "name": "gender",
                "value": "Male"
            },
                {
                    "name": "firstname",
                    "value": rstring
                },
                {
                    "name": "lastname",
                    "value": "Green"
                },
                {
                    "name": "email_address",
                    "value": emailAddr
                },
                {
                    "name": "password",
                    "value": "123456"
                },
                {
                    "name": "cmbmonth",
                    "value": "2"
                },
                {
                    "name": "cmbday",
                    "value": "18"
                },
                {
                    "name": "cmbyear",
                    "value": "1987"
                },
                {
                    "name": "City",
                    "value": "Aaronsburg,Pennsylvania"
                },
                {
                    "name": "State",
                    "value": "PA"
                },
                {
                    "name": "County",
                    "value": "Centre"
                },
                {
                    "name": "OnlyCity",
                    "value": "Aaronsburg"
                },
                {
                    "name": "verif_box",
                    "value": "8863"
                },
                {
                    "name": "interested_in",
                    "value": "2"
                },
                {
                    "name": "redirectURL",
                    "value": ""
                },
                {
                    "name": "signUp",
                    "value": "Sign Up"
                }],
            "mimeType": "application/x-www-form-urlencoded"
        },
        "queryString": [],
        "headers": [{
            "name": "Host",
            "value": "www.mysheriff.net"
        },
            {
                "name": "Connection",
                "value": "keep-alive"
            },
            {
                "name": "Content-Length",
                "value": "268"
            },
            {
                "name": "Cache-Control",
                "value": "max-age=0"
            },
            {
                "name": "Origin",
                "value": "http://www.mysheriff.net"
            },
            {
                "name": "Upgrade-Insecure-Requests",
                "value": "1"
            },
            {
                "name": "User-Agent",
                "value": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36"
            },
            {
                "name": "Content-Type",
                "value": "application/x-www-form-urlencoded"
            },
            {
                "name": "Accept",
                "value": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"
            },
            {
                "name": "Referer",
                "value": "http://www.mysheriff.net/users/"
            },
            {
                "name": "Accept-Encoding",
                "value": "gzip, deflate"
            },
            {
                "name": "Accept-Language",
                "value": "zh-CN,zh;q=0.8"
            },
            {
                "name": "Cookie",
                "value": "SR=8mlegk6rad4aj4f6fr99afds10; tntcon=39d0a8908fbe6c18039ea8227f827023a4xn; __atuvc=11%7C28; __atuvs=57823f263c1b2bc2006; __utma=110611609.1817649562.1468143855.1468143855.1468153583.2; __utmb=110611609.25.10.1468153583; __utmc=110611609; __utmz=110611609.1468143855.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)"
            }],
        "bodySize": 268,
        "url": "http://www.mysheriff.net/users/signup/",
        "cookies": [{
            "name": "SR",
            "value": "8mlegk6rad4aj4f6fr99afds10"
        },
            {
                "name": "tntcon",
                "value": "39d0a8908fbe6c18039ea8227f827023a4xn"
            },
            {
                "name": "__atuvc",
                "value": "11%7C28"
            },
            {
                "name": "__atuvs",
                "value": "57823f263c1b2bc2006"
            },
            {
                "name": "__utma",
                "value": "110611609.1817649562.1468143855.1468143855.1468153583.2"
            },
            {
                "name": "__utmb",
                "value": "110611609.25.10.1468153583"
            },
            {
                "name": "__utmc",
                "value": "110611609"
            },
            {
                "name": "__utmz",
                "value": "110611609.1468143855.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)"
            }],
        "method": "POST",
        "httpVersion": "HTTP/1.1"

    };

    // signUpHar.postData.params[3].value = emailAddr;

    request({ har: signUpHar }, function (err, resp, body) {
        fs.appendFileSync('emails.txt', emailAddr + '\r\n');

        var loginhar = {


            "headersSize": 872,
            "postData": {
                "params": [{
                    "name": "username",
                    "value": emailAddr
                },
                    {
                        "name": "password",
                        "value": "123456"
                    },
                    {
                        "name": "submit",
                        "value": "Sign In"
                    }],
                "mimeType": "application/x-www-form-urlencoded"
            },
            "queryString": [],
            "headers": [{
                "name": "Host",
                "value": "www.mysheriff.net"
            },
                {
                    "name": "Connection",
                    "value": "keep-alive"
                },
                {
                    "name": "Content-Length",
                    "value": "62"
                },
                {
                    "name": "Cache-Control",
                    "value": "max-age=0"
                },
                {
                    "name": "Origin",
                    "value": "http://www.mysheriff.net"
                },
                {
                    "name": "Upgrade-Insecure-Requests",
                    "value": "1"
                },
                {
                    "name": "User-Agent",
                    "value": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36"
                },
                {
                    "name": "Content-Type",
                    "value": "application/x-www-form-urlencoded"
                },
                {
                    "name": "Accept",
                    "value": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"
                },
                {
                    "name": "Referer",
                    "value": "http://www.mysheriff.net/"
                },
                {
                    "name": "Accept-Encoding",
                    "value": "gzip, deflate"
                },
                {
                    "name": "Accept-Language",
                    "value": "zh-CN,zh;q=0.8"
                },
                {
                    "name": "Cookie",
                    "value": "SR=nccri3fto6kjqriiddkhp4p6r0; __utmt=1; __utma=110611609.1743308010.1467679327.1467851631.1468299571.6; __utmb=110611609.8.10.1468299571; __utmc=110611609; __utmz=110611609.1467679327.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); __atuvc=6%7C27%2C2%7C28; __atuvs=578487c1faf28d91000"
                }],
            "bodySize": 62,
            "url": "http://www.mysheriff.net/users/signin/",
            "cookies": [{
                "name": "SR",
                "value": "nccri3fto6kjqriiddkhp4p6r0"
            },
                {
                    "name": "__utmt",
                    "value": "1"
                },
                {
                    "name": "__utma",
                    "value": "110611609.1743308010.1467679327.1467851631.1468299571.6"
                },
                {
                    "name": "__utmb",
                    "value": "110611609.8.10.1468299571"
                },
                {
                    "name": "__utmc",
                    "value": "110611609"
                },
                {
                    "name": "__utmz",
                    "value": "110611609.1467679327.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)"
                },
                {
                    "name": "__atuvc",
                    "value": "6%7C27%2C2%7C28"
                },
                {
                    "name": "__atuvs",
                    "value": "578487c1faf28d91000"
                }],
            "method": "POST",
            "httpVersion": "HTTP/1.1"
        };
        request({ har: loginhar, gzip: true }, function (err, resp, body) {
            if (err) console.log(err);
            var headers = resp.headers;
            for (var i in headers) {
                console.log(i + ' : ' + headers[i]);
            }

            var bhar = {

                // "headersSize": 899,
                "postData": {
                    "params": [{
                        "name": "hidPgRefRan",
                        "value": refNumber
                    },
                        {
                            "name": "siccode",
                            "value": sis
                        },
                        {
                            "name": "submit",
                            "value": "Save"
                        },
                        {
                            "name": "CompanyName",
                            "value": companyName
                        },
                        {
                            "name": "Address",
                            "value": address1
                        },
                        {
                            "name": "Address2",
                            "value": ""
                        },
                        {
                            "name": "City",
                            "value": city
                        },
                        {
                            "name": "State",
                            "value": "KS"
                        },
                        {
                            "name": "County",
                            "value": "Nemaha"
                        },
                        {
                            "name": "OnlyCity",
                            "value": "Sabetha"
                        },
                        {
                            "name": "searchDescription",
                            "value": businessType
                        },
                        {
                            "name": "zip",
                            "value": zip
                        },
                        {
                            "name": "phone1",
                            "value": phone1
                        },
                        {
                            "name": "phone2",
                            "value": phone2
                        },
                        {
                            "name": "phone3",
                            "value": phone3
                        },
                        {
                            "name": "EmailAddress",
                            "value": emailAddr
                        },
                        {
                            "name": "WebsiteAddress",
                            "value": companyWebsite
                        }
                        
                    ],
                    "mimeType": "application/x-www-form-urlencoded"
                },
                "queryString": [],
                "headers": [{
                    "name": "Host",
                    "value": "www.mysheriff.net"
                },
                    {
                        "name": "Connection",
                        "value": "keep-alive"
                    },
                    // {
                    //     "name": "Content-Length",
                    //     "value": "300"
                    // },
                    {
                        "name": "Cache-Control",
                        "value": "max-age=0"
                    },
                    {
                        "name": "Origin",
                        "value": "http://www.mysheriff.net"
                    },
                    {
                        "name": "Upgrade-Insecure-Requests",
                        "value": "1"
                    },
                    {
                        "name": "User-Agent",
                        "value": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36"
                    },
                    {
                        "name": "Content-Type",
                        "value": "application/x-www-form-urlencoded"
                    },
                    {
                        "name": "Accept",
                        "value": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"
                    },
                    {
                        "name": "Referer",
                        "value": "http://www.mysheriff.net/users/business/add/"
                    },
                    {
                        "name": "Accept-Encoding",
                        "value": "gzip, deflate"
                    },
                    {
                        "name": "Accept-Language",
                        "value": "zh-CN,zh;q=0.8"
                    },
                    {
                        "name": "Cookie",
                        "value": "SR=nccri3fto6kjqriiddkhp4p6r0; __utmt=1; __atuvc=6%7C27%2C2%7C28; __atuvs=578487c1faf28d91000; __utma=110611609.1743308010.1467679327.1467851631.1468299571.6; __utmb=110611609.10.10.1468299571; __utmc=110611609; __utmz=110611609.1467679327.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)"
                    }],
                // "bodySize": 300,
                "url": "http://www.mysheriff.net/users/business/add/",
                "cookies": [{
                    "name": "SR",
                    "value": "nccri3fto6kjqriiddkhp4p6r0"
                },
                    {
                        "name": "__utmt",
                        "value": "1"
                    },
                    {
                        "name": "__atuvc",
                        "value": "6%7C27%2C2%7C28"
                    },
                    {
                        "name": "__atuvs",
                        "value": "578487c1faf28d91000"
                    },
                    {
                        "name": "__utma",
                        "value": "110611609.1743308010.1467679327.1467851631.1468299571.6"
                    },
                    {
                        "name": "__utmb",
                        "value": "110611609.10.10.1468299571"
                    },
                    {
                        "name": "__utmc",
                        "value": "110611609"
                    },
                    {
                        "name": "__utmz",
                        "value": "110611609.1467679327.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)"
                    }],
                "method": "POST",
                "httpVersion": "HTTP/1.1"

            }

            var timestamp = Date.now();

            var bthar = {
                "headersSize": 748,
                "postData": {
                    "text": "",
                    "mimeType": ""
                },
                "queryString": [{
                    "name": "q",
                    "value": businessType.substring(0, 2)
                },
                    {
                        "name": "limit",
                        "value": "10"
                    },
                    {
                        "name": "timestamp",
                        "value": "1468303625608"
                    }],
                "headers": [{
                    "name": "Host",
                    "value": "www.mysheriff.net"
                },
                    {
                        "name": "Connection",
                        "value": "keep-alive"
                    },
                    {
                        "name": "Accept",
                        "value": "*/*"
                    },
                    {
                        "name": "X-Requested-With",
                        "value": "XMLHttpRequest"
                    },
                    {
                        "name": "User-Agent",
                        "value": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36"
                    },
                    {
                        "name": "Referer",
                        "value": "http://www.mysheriff.net/users/business/add/"
                    },
                    {
                        "name": "Accept-Encoding",
                        "value": "gzip, deflate, sdch"
                    },
                    {
                        "name": "Accept-Language",
                        "value": "zh-CN,zh;q=0.8"
                    },
                    {
                        "name": "Cookie",
                        "value": "SR=nccri3fto6kjqriiddkhp4p6r0; __utmt=1; __atuvc=6%7C27%2C2%7C28; __atuvs=578487c1faf28d91000; __utma=110611609.1743308010.1467679327.1467851631.1468299571.6; __utmb=110611609.10.10.1468299571; __utmc=110611609; __utmz=110611609.1467679327.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)"
                    }],
                "bodySize": 0,
                "url": "http://www.mysheriff.net/getTypeOfBusiness.php?q=" + businessType.substring(0, 2) + "&limit=10&timestamp=" + timestamp,
                "cookies": [{
                    "name": "SR",
                    "value": "nccri3fto6kjqriiddkhp4p6r0"
                },
                    {
                        "name": "__utmt",
                        "value": "1"
                    },
                    {
                        "name": "__atuvc",
                        "value": "6%7C27%2C2%7C28"
                    },
                    {
                        "name": "__atuvs",
                        "value": "578487c1faf28d91000"
                    },
                    {
                        "name": "__utma",
                        "value": "110611609.1743308010.1467679327.1467851631.1468299571.6"
                    },
                    {
                        "name": "__utmb",
                        "value": "110611609.10.10.1468299571"
                    },
                    {
                        "name": "__utmc",
                        "value": "110611609"
                    },
                    {
                        "name": "__utmz",
                        "value": "110611609.1467679327.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)"
                    }],
                "method": "GET",
                "httpVersion": "HTTP/1.1"

            }
            //

            var cityhar = {

                "headersSize": 762,
                "postData": {
                    "text": "",
                    "mimeType": ""
                },
                "queryString": [{
                    "name": "q",
                    "value": city.substring(0, 4)
                },
                    {
                        "name": "limit",
                        "value": "10"
                    },
                    {
                        "name": "timestamp",
                        "value": timestamp
                    }],
                "headers": [{
                    "name": "Host",
                    "value": "www.mysheriff.net"
                },
                    {
                        "name": "Connection",
                        "value": "keep-alive"
                    },
                    {
                        "name": "Accept",
                        "value": "*/*"
                    },
                    {
                        "name": "X-Requested-With",
                        "value": "XMLHttpRequest"
                    },
                    {
                        "name": "User-Agent",
                        "value": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36"
                    },
                    {
                        "name": "Referer",
                        "value": "http://www.mysheriff.net/users/business/add/"
                    },
                    {
                        "name": "Accept-Encoding",
                        "value": "gzip, deflate, sdch"
                    },
                    {
                        "name": "Accept-Language",
                        "value": "zh-CN,zh;q=0.8"
                    },
                    {
                        "name": "Cookie",
                        "value": "SR=nccri3fto6kjqriiddkhp4p6r0; __atuvc=6%7C27%2C2%7C28; __atuvs=578487c1faf28d91000; __utmt=1; __utma=110611609.1743308010.1467679327.1467851631.1468299571.6; __utmb=110611609.14.10.1468299571; __utmc=110611609; __utmz=110611609.1467679327.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)"
                    }],
                "bodySize": 0,
                "url": "http://www.mysheriff.net/getTownsWithStates.php?q=" + city.substring(0, 2) + "&limit=10&timestamp=" + timestamp,
                "cookies": [{
                    "name": "SR",
                    "value": "nccri3fto6kjqriiddkhp4p6r0"
                },
                    {
                        "name": "__atuvc",
                        "value": "6%7C27%2C2%7C28"
                    },
                    {
                        "name": "__atuvs",
                        "value": "578487c1faf28d91000"
                    },
                    {
                        "name": "__utmt",
                        "value": "1"
                    },
                    {
                        "name": "__utma",
                        "value": "110611609.1743308010.1467679327.1467851631.1468299571.6"
                    },
                    {
                        "name": "__utmb",
                        "value": "110611609.14.10.1468299571"
                    },
                    {
                        "name": "__utmc",
                        "value": "110611609"
                    },
                    {
                        "name": "__utmz",
                        "value": "110611609.1467679327.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)"
                    }],
                "method": "GET",
                "httpVersion": "HTTP/1.1"

            }

            request = request.defaults({ proxy: 'http://localhost:8888' });
            request({ url: "http://www.mysheriff.net/getTypeOfBusiness.php?q=" + businessType.substring(0, 2) + "&limit=10&timestamp=" + timestamp, method: 'GET', har: cityhar, gzip: true }, function (err, resp, body) {
                request({ url: "http://www.mysheriff.net/getTownsWithStates.php?q=" + city.substring(0, 4) + "&limit=10&timestamp=" + timestamp, method: 'GET', har: bthar, gzip: true }, function (err, resp, body) {
                    if (err) console.log(err);
                    request({ url: 'http://www.mysheriff.net/users/business/add/', method: 'POST', har: bhar, gzip: true }, function (err, resp, body) {
                        var headers = resp.headers;
                        for (var i in headers) {
                            console.log(i + ' : ' + headers[i]);
                        }
                        setTimeout(function() {
                            console.log(emailAddr + ' was done');
                            callback(null);
                        }, 2500);
                    });
                });
            });
        });
    });
};