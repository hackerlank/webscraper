/// <reference path="typings/node/node.d.ts" />
/// <reference path="typings/angular-protractor/angular-protractor.d.ts" />
/// <reference path="typings/async/async.d.ts" />
/// <reference path="typings/request/request.d.ts" />
/// <reference path="typings/cheerio/cheerio.d.ts" />